<?php

return [
    'author'                =>'লেখক :',
];
